package Game;

public class Potion {
    public void use() {}
}
